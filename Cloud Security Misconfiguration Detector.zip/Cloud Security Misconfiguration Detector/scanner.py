import webbrowser
import os
from collections import Counter

# --------------------------------------------------
# STEP 1 — MOCK DATA
# --------------------------------------------------
results = [
    {"type":"S3","resource":"public-bucket","issue":"Public S3 Bucket","severity":"HIGH"},
    {"type":"S3","resource":"data-bucket","issue":"No Encryption Enabled","severity":"MEDIUM"},
    {"type":"S3","resource":"backup-bucket","issue":"Versioning Disabled","severity":"LOW"},
    {"type":"IAM","resource":"developer","issue":"MFA Not Enabled","severity":"HIGH"},
    {"type":"SecurityGroup","resource":"web-sg","issue":"Open Port 22","severity":"HIGH"},
    {"type":"SecurityGroup","resource":"db-sg","issue":"Open Port 3389","severity":"HIGH"}
]

# --------------------------------------------------
# STEP 2 — COUNT SEVERITIES
# --------------------------------------------------
severity_counts = Counter(r['severity'] for r in results)
high_count = severity_counts.get('HIGH', 0)
medium_count = severity_counts.get('MEDIUM', 0)
low_count = severity_counts.get('LOW', 0)

print("\nScan Summary:")
print(f"HIGH: {high_count}, MEDIUM: {medium_count}, LOW: {low_count}")

# --------------------------------------------------
# STEP 3 — BUILD HTML DASHBOARD
# --------------------------------------------------
html_content = f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Cloud Security Dashboard</title>
<style>
body {{ font-family: Arial; background: #f4f6f8; margin: 20px; }}
h1, h2 {{ text-align: center; }}
table {{ border-collapse: collapse; width: 90%; margin: auto; }}
th, td {{ border: 1px solid #ddd; padding: 8px; text-align: center; }}
th {{ background-color: #2c3e50; color: white; }}
tr:nth-child(even) {{ background-color: #f2f2f2; }}
.HIGH {{ background-color: #ff4d4d; color: white; }}
.MEDIUM {{ background-color: #ffa500; color: white; }}
.LOW {{ background-color: #ffff66; }}
.summary-box {{ width: 60%; margin: 20px auto; padding: 15px; background: white; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); text-align: center; }}
.diagram-box {{ padding: 20px; border: 2px solid #2c3e50; border-radius: 10px; background: white; text-align: center; width: 150px; margin: 0 auto; }}
.diagram-container {{ display: flex; justify-content: space-around; align-items: center; margin: 30px auto; flex-wrap: wrap; gap: 20px; }}
</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<h1>Cloud Security Misconfiguration Dashboard</h1>

<div class="summary-box">
<h3>Scan Summary</h3>
<p><b>High Risk Issues:</b> {high_count}</p>
<p><b>Medium Risk Issues:</b> {medium_count}</p>
<p><b>Low Risk Issues:</b> {low_count}</p>
</div>

<h2>Architecture Diagram</h2>
<div class="diagram-container">
<div class="diagram-box"><b>IAM Users</b><br>developer</div>
<div class="diagram-box"><b>S3 Buckets</b><br>public-bucket<br>data-bucket<br>backup-bucket</div>
<div class="diagram-box"><b>Security Groups</b><br>web-sg<br>db-sg</div>
</div>

<h2>Severity Distribution</h2>
<canvas id="severityChart" width="300" height="200" style="display:block; margin:0 auto;"></canvas>

<script>
const ctx = document.getElementById('severityChart').getContext('2d');
new Chart(ctx, {{
    type: 'pie',
    data: {{
        labels: ['HIGH', 'MEDIUM', 'LOW'],
        datasets: [{{
            data: [{high_count}, {medium_count}, {low_count}],
            backgroundColor: ['#ff4d4d', '#ffa500', '#ffff66']
        }}]
    }},
    options: {{
        responsive: false,
        plugins: {{
            legend: {{ position: 'bottom' }},
            title: {{ display: true, text: 'Issues by Severity' }}
        }}
    }}
}});
</script>

<h2>Detailed Scan Results</h2>
<table>
<thead>
<tr>
<th>Resource Type</th>
<th>Resource Name</th>
<th>Issue</th>
<th>Severity</th>
</tr>
</thead>
<tbody>
"""

# Add each result to the table
for r in results:
    html_content += f"""
<tr>
<td>{r['type']}</td>
<td>{r['resource']}</td>
<td>{r['issue']}</td>
<td class="{r['severity']}">{r['severity']}</td>
</tr>
"""

html_content += """
</tbody>
</table>
</body>
</html>
"""

# --------------------------------------------------
# STEP 4 — SAVE AND OPEN REPORT
# --------------------------------------------------
output_file = "cloud_security_report.html"
with open(output_file, "w", encoding="utf-8") as f:
    f.write(html_content)

full_path = os.path.abspath(output_file)
print(f"\n[+] Report generated at:\n{full_path}")

# Open automatically in browser
webbrowser.open(f"file://{full_path}")
for r in results:
    print(f"[{r['severity']}] {r['resource']} - {r['issue']}")
